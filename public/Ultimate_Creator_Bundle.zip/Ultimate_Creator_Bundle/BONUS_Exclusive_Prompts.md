# Ultimate Bundle Exclusive Prompts

Thank you for purchasing the Ultimate Creator Bundle! Here are 5 mega-prompts that connect strategy, copy, and visual generation together.

**The "Campaign in a Box" Prompt:**
"Act as a full-stack marketing agency. I am launching [Product]. 
1. Give me 3 Midjourney prompts for the visual assets.
2. Give me 3 Facebook Ad variations (AIDA framework).
3. Give me 5 TikTok script hooks to drive organic traffic.
4. Give me a 3-email sequence to send to my newsletter."
