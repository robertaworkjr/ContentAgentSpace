# 30-Day Content Calendar Generator

**Prompt:**
"Act as a Social Media Strategist. Create a 30-day content calendar for a [Your Niche] brand on [Platform]. 
Distribute the content into these pillars:
- 40% Educational/Value-driven
- 20% Entertaining/Relatable
- 20% Personal Story/Behind the scenes
- 20% Promotional/Sales

Format the output as a table with columns: Day, Content Pillar, Post Idea, Hook, Format (Video/Carousel/Text)."
