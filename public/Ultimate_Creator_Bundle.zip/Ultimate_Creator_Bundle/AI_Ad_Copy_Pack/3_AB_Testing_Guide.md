# A/B Testing Guide for Ad Copy

Never test more than one variable at a time. Here is the hierarchy of what to test:
1. **The Visual (Creative):** This drives 80% of the results. 
2. **The Hook (First sentence):** If the visual stops them, the hook gets them to read more. Test 3 different hooks with the same body.
3. **The Offer:** Try testing "$10 Off" vs "20% Off" (people perceive percentages differently based on price).
4. **The CTA:** "Shop Now" vs "Learn More".
