# AIDA & PAS Ad Copy Prompt Frameworks

## The AIDA Framework (Attention, Interest, Desire, Action)
**Prompt:**
"Act as a direct-response copywriter. Write a Facebook Ad using the AIDA framework for [Product/Service]. 
- Attention: Call out [Target Audience] with a shocking statistic about [Pain Point].
- Interest: Explain the science/reasoning behind why they are struggling.
- Desire: Paint a picture of what their life looks like after using [Product/Service].
- Action: Tell them exactly what to click and what they get."

## The PAS Framework (Problem, Agitate, Solve)
**Prompt:**
"Write an Instagram Ad caption for [Product/Service].
- Problem: State [Specific Problem] clearly in the first sentence.
- Agitate: Emphasize the hidden costs of NOT solving this problem (time, money, stress).
- Solve: Position [Product/Service] as the inevitable, easiest solution. Provide 3 bullet points of benefits."
