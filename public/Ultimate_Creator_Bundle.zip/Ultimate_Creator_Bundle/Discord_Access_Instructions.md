# Priority Discord Access

Welcome to the community!

To claim your priority access to the ContentAgent.Space private Discord:
1. Click this link to join: https://discord.gg/your-invite-link
2. Navigate to the #verify channel.
3. Open a ticket and paste your Stripe receipt or email address.
4. A moderator will grant you the "Ultimate Creator" role, unlocking the private prompt channels and quarterly update drops!
