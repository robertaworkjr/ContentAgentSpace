# AI Prompt Engineering Guide for Short-Form Video

Copy and paste these prompts into Claude, ChatGPT, or Gemini to generate high-quality, retention-optimized video scripts.

## Prompt 1: The "Listicle" Script Generator
Use this when you want to share 3-5 tips, tools, or secrets.

**The Prompt:**
> "Act as an expert TikTok and Reels scriptwriter who understands viewer retention. Write a 45-second script about [INSERT TOPIC HERE]. 
> 
> Follow this structure:
> 1. Start with a controversial or highly curious hook.
> 2. List 3 distinct points. Make them punchy.
> 3. Keep all sentences under 12 words to ensure fast-paced delivery.
> 4. Include a strong Call to Action (CTA) at the end asking the viewer to [INSERT DESIRED ACTION, e.g., save this video, comment a word for a link].
> 5. Add bracketed instructions for the editor (e.g., [Cut to B-Roll], [Text Pop-up], [Sound Effect])."

---

## Prompt 2: The "Contrarian Opinion" Script
Use this to challenge a common belief in your industry and stand out.

**The Prompt:**
> "Write a 30-second vertical video script that argues against the common belief that [INSERT COMMON BELIEF, e.g., 'you need a lot of money to start investing']. 
> 
> The tone should be confident and slightly disruptive. 
> - Hook: State the controversial opinion immediately within the first 3 seconds.
> - Body: Explain WHY the common belief is wrong, and provide your alternative solution.
> - Provide a real-world example or quick logic to back up the claim.
> - CTA: Ask the viewer 'Do you agree? Let me know below.'
> - Format the script in a two-column table: Left column for 'Visual/Audio Cues', Right column for 'Spoken Word'."

---

## Prompt 3: The "Personal Story / Case Study"
Use this to build trust and show real results.

**The Prompt:**
> "I want to tell a story about how I achieved [INSERT RESULT] in [INSERT TIMEFRAME] by doing [INSERT ACTION]. 
> 
> Write a 60-second script optimized for YouTube Shorts. 
> 
> Structure:
> 1. Hook: Reveal the final impressive result first.
> 2. The Valley: Talk about the struggle or where I started (to build empathy).
> 3. The Pivot: Introduce the specific strategy or tool that changed everything.
> 4. The Execution: Briefly explain the 2-3 steps taken.
> 5. CTA: Tell them to follow for a deep dive into step 1."

---

## Pro-Tips for Prompting:
*   **Always dictate sentence length:** AI tends to write long, run-on sentences. Tell it to "Keep sentences under 10 words" so you don't run out of breath while recording.
*   **Ask for variations:** If you don't like the first output, say "Give me 3 more variations of the hook, make them more aggressive."
*   **Tone is everything:** Tell the AI to act "casual like a FaceTime call with a friend" or "high-energy like a tech review."