# The Retention Editing Checklist

Great scripts mean nothing if your editing allows the viewer to get bored. Use this checklist on every video before you post.

### [ ] The 3-Second Rule
- Does the visual change within the first 3 seconds? (e.g., a zoom in, a text pop-up, a B-roll cut). The brain needs a "reset" to stay engaged.

### [ ] Dead Air Removal (The J-Cut)
- Did you remove ALL breaths, "umms", and pauses? 
- **Pro Tip:** Overlap the audio of the next sentence slightly before the video of the previous sentence finishes. This forces the viewer into the next thought seamlessly.

### [ ] Captions (Dynamic, not static)
- Are there captions on screen?
- Do the captions highlight 1-3 words at a time rather than a whole sentence? (This forces the eye to track the text, keeping them glued to the screen).

### [ ] Sound Design
- Did you add a subtle "whoosh" or "pop" sound effect when text appears on screen or when a transition happens? (Audio cues signal the brain that something new is happening).

### [ ] Visual Hierarchy
- Is the text placed in the "safe zone"? (Not covered by the like button, description, or top UI elements on TikTok/Reels).

### [ ] The Loop
- Does the end of the video seamlessly transition back into the beginning of the video? 
- *Example:* End your video by saying "And that is exactly..." and make sure the hook of the video starts with "...why you need to stop doing this."