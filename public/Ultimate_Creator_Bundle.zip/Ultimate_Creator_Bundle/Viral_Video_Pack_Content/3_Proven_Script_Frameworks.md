# Proven Script Frameworks for Viral Content

Don't guess what works. Follow the psychology of human attention. Here are the 3 most effective frameworks for short-form video.

## 1. The H.S.O. Framework (Hook, Story, Offer)
*Best for: Selling a product or service.*

*   **Hook (0-3 seconds):** Grab attention by calling out the target audience or stating a massive benefit/pain point.
    *   *Example:* "If you are a freelancer working 60 hours a week, you need to hear this."
*   **Story/Value (3-25 seconds):** Empathize with the problem, explain why it happens, and introduce your unique mechanism to solve it. Keep it fast.
    *   *Example:* "I used to do the same until I realized I was doing all the manual work. Once I implemented this one automation..."
*   **Offer/CTA (25-30 seconds):** Tell them exactly what to do next to get the solution.
    *   *Example:* "I put together a free guide showing you how to set this up. Comment 'AUTOMATE' and I'll DM it to you."

## 2. The P.A.S. Framework (Problem, Agitate, Solve)
*Best for: Educational content and establishing authority.*

*   **Problem:** State a problem your audience hates.
    *   *Example:* "Are your TikTok videos stuck at 200 views?"
*   **Agitate:** Make the problem feel worse. Remind them of the pain of NOT fixing it.
    *   *Example:* "It's incredibly frustrating to spend 3 hours editing a video just for the algorithm to completely ignore it while your competitors go viral."
*   **Solve:** Present the fix.
    *   *Example:* "The issue isn't your lighting, it's your retention rate. Here is the 3-second rule you need to start using..."

## 3. The Myth-Buster
*Best for: Driving comments, shares, and high engagement through mild controversy.*

*   **The Myth:** State a widely accepted "truth" in your niche.
    *   *Example:* "Everyone tells you that you need to post 3 times a day to grow on Instagram."
*   **The Bust:** Completely invalidate the myth.
    *   *Example:* "That is the fastest way to burn out and destroy your engagement rate."
*   **The Truth:** Provide the actual data or your specific strategy.
    *   *Example:* "I post 3 times a *week*, but I spend 80% of my time optimizing the hook and the script. Here is my exact workflow..."