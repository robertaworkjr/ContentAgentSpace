# Engagement Triggers (Getting Comments)

The algorithm rewards comments more than likes. Use these structures:

**The Polarizing Question:**
"Unpopular opinion: [Opinion]. Do you agree or am I crazy? Let me know below."

**The A/B Choice:**
"Are you Team A or Team B? 👇"

**The "Save for Later":**
"This took me 4 years to learn. Save this post so you don't forget it."
