# Locking in your Aesthetic on Midjourney

To maintain a consistent brand look, append your "Style Seed" to every prompt.

**Example Minimalist Brand Style Seed:**
`--ar 4:5 --stylize 250 --v 6.0 --style raw, muted color palette, soft natural lighting, minimalist composition, Kodak Portra 400`

**Example Bold/Tech Brand Style Seed:**
`--ar 16:9 --stylize 400 --v 6.0, neon cyberpunk accents, high contrast, studio lighting, hyper-detailed, unreal engine 5 render`
