# Platform Size Variations

Always append the aspect ratio parameter (`--ar`) at the end of your Midjourney prompts:
- **Instagram/Facebook Feed:** `--ar 4:5` (Vertical, optimal screen space) or `--ar 1:1` (Square)
- **YouTube Thumbnail / Twitter:** `--ar 16:9` (Widescreen)
- **TikTok / Reels / Shorts / Stories:** `--ar 9:16` (Full vertical)
